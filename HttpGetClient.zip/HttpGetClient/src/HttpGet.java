import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import org.apache.commons.codec.binary.Base64;

public class HttpGet {

	//A String that will be altered and cut to find the desired information
	public static String equipLine = "";
	
	//an int that will count the total number of equipment that belongs to that company
	public static int numEquip = 0;

	/*
	 * Calls the HTTP GET with basic auth and sets "equipLine" which is the string
	 * that holds all data from the GET
	 */
	public static void run() {
		String path = "https://service.equipchat.com/EquipchatTransactionService.svc/GetEquipment";
		//String path = "https://service.equipchat.com/EquipchatTransactionService.svc/GetHours/09-15-2018/10-15-2018";
		String line = "";
		try {
			URL url = new URL(path);
			URLConnection urlConnection = setUsernamePassword(url);
			BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
			while ((line = reader.readLine()) != null) {
				equipLine = line;
				//System.out.println(line);
				numEquip++;
			}
			reader.close();
			
//			String[] info = equipLine.split(":");
//			int i = 0;
			
//			for(String s : info) {
//				System.out.println(i + "    " + s);
//				i++;
//			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	//Basic authentication set up
	private static URLConnection setUsernamePassword(URL url) throws IOException {
		String username = "rtosten";
		String password = "BTedu18";
		URLConnection urlConnection = url.openConnection();
		String authString = username + ":" + password;
		String authStringEnc = new String(Base64.encodeBase64(authString.getBytes()));
		urlConnection.setRequestProperty("Authorization", "Basic " + authStringEnc);
		return urlConnection;
	}

	/**
	 * Checks in the equipLine to see if the equipment is in the get response
	 * @param equipment --> the equipment to search for
	 * @return --> true if the equipment exists, false otherwise
	 */
	public static boolean hasEquip(String equipment){
		if( equipLine.contains(equipment)){
			return true;
		}
		else {

		}	return false;
	}

	/**
	 * Returns the number of equipment as an int
	 * @return --> the number of equipment as an int
	 */
	public static int equipTotal() {
		return numEquip;
	}

	/**
	 * Checks if the desired equipment is available or not
	 * @return --> String containing either true or false
	 */
	public static String equipStatus(){
		//CMH is at info[4]
		String[] info = equipLine.split(":");

		info = info[1].split(",");

		System.out.println("The equipment is available: "+ info[0]);
		return info[0];
	}

	/**
	 * Gets the CMH (cumulative machine hours) and returns it as a String
	 * @return --> The CMH represented as a String
	 */
	public static String equipCMH(){
		//CMH is at info[4]
		String[] info = equipLine.split(":");

		info = info[4].split(",");

		System.out.println("Total CMH: "+ info[0]);
		return info[0];
	}	
	
	/**
	 * Gets the last date that information was pulled from the sensor and put onto the portal
	 * @return --> The date of last transaction as a String
	 */
	public static String lastTransaction() {
		String[] info = equipLine.split(":");
		
		info = info[15].split(" ");
		
		info = info[0].split("\"");
		
		System.out.println("The last transaction date: "+info[1]);
		return info[1];
	}
	
	/**
	 * Returns the transaction number of latest transaction
	 * @return --> A String containing the transaction number for the latest transaction
	 */
	public static String transactionInfo() {
		String[] info = equipLine.split(":");
		
		info = info[21].split(" ");
		
		info = info[0].split(",");
		
		System.out.println("Last transaction number: "+ info[0]);
		return info[0];
	}
	
	/**
	 * Gets the make model and jobsite of the equipment 
	 * @return --> returns a String array of the make, model and jobsite of the equipment
	 */
	public static String[] equipInfo() {
		String[] allInfo = new String[3];
		String[] info = equipLine.split(":");
		
		String make = info[22].split(",")[0];		
		//System.out.println(make);
		
		if(make.equals("null")){
			make = "No make specified";
		}
		
		String model = info[23].split(",")[0];
		//System.out.println(model);
		
		if(model.equals("null")){
			model = "No model specified";
		}
		
		String jobsite = info[14].split(",")[0];
		//System.out.println(jobsite);
		
		jobsite = jobsite.split("\"")[1];
		//System.out.println(jobsite);
		
		allInfo[0] = make;
		allInfo[1] = model;
		allInfo[2] = jobsite;
		
		for( String s : allInfo ) {
			System.out.println(s);
		}
		
		return allInfo;
	}

	public static void main(String[] args) {
		run();
		System.out.println();
		
//		String[] info = equipLine.split(":");
//		for( String s : info ) {
//			System.out.println(s);
//		}
//		System.out.println();
		
		boolean hasLongboard = hasEquip("Longboard");
		boolean hasLongboard2 = hasEquip("longboard");
		boolean hasLongboard3 = hasEquip( "board");
		boolean hasLongboard4 = hasEquip("Long");

		System.out.println("The equipment list contains longboard: " + hasLongboard);
		System.out.println("The equipment list contains longboard: " + hasLongboard2);
		System.out.println("The equipment list contains longboard: " + hasLongboard3);
		System.out.println("The equipment list contains longboard: " + hasLongboard4);
		System.out.println();

		System.out.println("Total number of equipment: "+ equipTotal());
		System.out.println();

		equipStatus();
		System.out.println();

		equipCMH();
		System.out.println();
		
		lastTransaction();
		System.out.println();
		
		transactionInfo();
		System.out.println();
		
		equipInfo();
		System.out.println();
	}
}