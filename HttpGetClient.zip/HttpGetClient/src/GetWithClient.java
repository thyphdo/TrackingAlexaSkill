import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

@SuppressWarnings("deprecation")
public class GetWithClient {

	public void getHttpStatus() throws Exception {

        @SuppressWarnings("resource")
		DefaultHttpClient httpclient = new DefaultHttpClient();
        try {
        	//Creates the client that will house the username, password, host, port, realm, and scheme
            httpclient.getCredentialsProvider().setCredentials(
            		//AuthScope sets the host and port number
            		new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT, AuthScope.ANY_REALM, AuthScope.ANY_SCHEME),
                    //sets credentials for the get
                    new UsernamePasswordCredentials("rtosten", "BTedu18"));
                    //new UsernamePasswordCredentials("cnRvc3Rlbg==", "QlRlZHUxOA=="));

            //The HttpGet object retrieves any data at the given url/String 
            //HttpGet httpget = new HttpGet("https://service.equipchat.com/EquipchatTransactionService.svc/GetEquipment");
            
            HttpGet httpget = new HttpGet("http://devservice.equipchat.com/EquipchatTransactionService.svc/Equipment/2cdef339-9e7f-4315-8f8f-cbb4763e7776");
            
            System.out.println("executing request" + httpget.getRequestLine());
            //The response from the server
            HttpResponse response = httpclient.execute(httpget);
            //HttpEntity gets the response from the GET method
            HttpEntity entity = response.getEntity();

            System.out.println("----------------------------------------");
            System.out.println(response.getStatusLine());
            if (entity != null) {
               // System.out.println("Response content length: " + entity.getContentLength());
                System.out.println("----------------------------------------");
                long len = entity.getContentLength();
                if (len != -1 && len < 10000) {
                    System.out.println(EntityUtils.toString(entity));
                }
            }

            EntityUtils.consume(entity);

        } finally {
            httpclient.getConnectionManager().shutdown();
        }

    }
	
	public static void main(String[] args) {
		 
		GetWithClient basicAuth = new GetWithClient();
        try {
			basicAuth.getHttpStatus();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
